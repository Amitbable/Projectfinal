package com.cg.admin.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.admin.dao.BookingInfoDao;
import com.cg.admin.dao.BookingInfoDaoImpl;
import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;

public class BookingInfoService implements IBookingInfoService {
BookingInfoDao bDao=new BookingInfoDaoImpl();
	

	@Override
	public int countBookingIds(int fno) throws AdminException 
	{
		
		return bDao.countBookingIds(fno);
	}


	@Override
	public List<BookingInformation> getAllBookings(int flightNo)
			throws AdminException 
	{
		
		return bDao.getAllBookings(flightNo);
	}


	@Override
	public int addNewBookingInformation(BookingInformation bookInfo)
			throws BookingException 
	{
	
		return bDao.addNewBookingInformation(bookInfo);
	}


	@Override
	public BookingInformation getBookingInformation(int bookingId)
			throws BookingException 
	{
	
		return bDao.getBookingInformation(bookingId);
	}


	@Override
	public boolean deleteBookingInformation(int id) throws BookingException 
	{
		return bDao.deleteBookingInformation(id);
	}


	@Override
	public ArrayList<FlightInformation> searchFlightInformation(String src,
			String destination) throws BookingException 
			{
				
			String source=src.toLowerCase();
			String des=destination.toLowerCase();
		return bDao.searchFlightInformation(source, des);
	}


	@Override
	public FlightInformation getParticularFlight(int fno)
			throws BookingException 
	{

		return bDao.getParticularFlight(fno);
	}


	@Override
	public boolean updateFlightSeatsCNF(FlightInformation f)
			throws BookingException
	{
		return bDao.updateFlightSeatsCNF(f);
	}


	@Override
	public boolean validateEmail(String email) throws BookingException 
	{
		String emailPattern="[a-zA-Z0-9]{2,20}[@][a-zA-Z]{2,10}[.][a-zA-Z]{2,4}";
		if(Pattern.matches(emailPattern, email))
		{
			return true;
		}
		else
		{
			System.err.println("Please enter a valid Email Id");
			return false;
		}
	}


	@Override
	public boolean validateCc(String cc) throws BookingException 
	{
		String ccPattern="^(?:(?<visa>4[0-9]{12}(?:[0-9]{3})?)|" +
        "(?<mastercard>5[1-5][0-9]{14})|" +
        "(?<discover>6(?:011|5[0-9]{2})[0-9]{12})|" +
        "(?<amex>3[47][0-9]{13})|" +
        "(?<diners>3(?:0[0-5]|[68][0-9])?[0-9]{11})|" +
        "(?<jcb>(?:2131|1800|35[0-9]{3})[0-9]{11}))$";
		if(Pattern.matches(ccPattern, cc))
		{
			return true;
		}
		else
		{
			System.err.println("Please enter a valid Credit Card Number"
					+ "\n1. Visa : 13 or 16 digits, starting with 4."
					+ "\n2. MasterCard : 16 digits, starting with 51 through 55."
					+ "\n3. Discover : 16 digits, starting with 6011 or 65."
					+ "\n4. American Express : 15 digits, starting with 34 or 37."
					+ "\n5. Diners Club : 14 digits, starting with 300 through 305, 36, or 38."
					+ "\n6. JCB : 15 digits, starting with 2131 or 1800, or 16 digits starting with 35.");
			return false;
		}
	}



}
