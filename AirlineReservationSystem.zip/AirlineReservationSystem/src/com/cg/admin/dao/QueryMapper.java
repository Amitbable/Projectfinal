package com.cg.admin.dao;

public interface QueryMapper 
{
	String INSERT_USER="INSERT INTO users values(?,?,?,?)";
	String CHECK_USERNAME="SELECT username FROM users WHERE password=?";
	String CHECK_ROLE="SELECT role FROM users WHERE username=? AND password=?";
	//String SEQUENCE_FLIGHT_NO="SELECT flt_no_seq.NEXTVAL FROM DUAL";
	String SEQUENCE_BOOKING_ID="SELECT book_id_seq.NEXTVAL FROM DUAL";
	String Update_SUCCESS_SEATS="UPDATE FLIGHTINFORMATION SET FIRSTSEATSAVAIL=?,BUSSSEATSAVAIL=?  WHERE FLIGHTNO = ?";
	String INSERT_FLIGHT_INFORMATION="INSERT INTO flightInformation values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	String SELECT_ALL_FLIGHTS="SELECT * FROM flightInformation";
	String SELECt_PARTICULAR_FLIGHT="SELECT * FROM FLIGHTINFORMATION WHERE FLIGHTNO LIKE ?";
	String UPDATE_ARR_TIME="UPDATE flightInformation set arrTime=? WHERE flightNo=?";
	String UPDATE_DEPT_TIME="UPDATE flightInformation set deptTime=? WHERE flightNo=?";
	String UPDATE_FIRST_FARES="UPDATE flightInformation set firstSeatsFare=? WHERE flightNo=?";
	String UPDATE_BUSS_FARES="UPDATE flightInformation set bussSeatsFare=? WHERE flightNo=?";
	String UPDATE_ARR_CITY="UPDATE flightInformation set destination=? WHERE flightNo=?";
	String UPDATE_DEPT_CITY="UPDATE flightInformation set source=? WHERE flightNo=?";
	String BOOKINGS_FOR_SPECIFIC_FLIGHT="SELECT count(bookingId) AS No_Of_Bookings FROM bookingInformation where flightNo=? group by flightNo";
	String SELECT_PASSGR_DET_FOR_SPECIFIC_FLT="SELECT * FROM bookingInformation where flightNo=?";
	String SELECT_FLIGHT_PAR_DAY_PAR_CITY="SELECT * FROM flightInformation where destination=? AND departuredate=?";
	String SELECT_FLIGHT_PAR_DAY_PAR_CITY1="SELECT * FROM flightInformation where deptCity=? AND deptDate=?";
	String UPDATE_FLIGHT_INFO="UPDATE flightInformation set airline=?, deptCity=?, arrCity=?, deptDate=?,"
			+ " arrDate=?, deptTime=?, arrTime=?, firstSeats=? firstSeatsFares=?, bussSeats=?, bussSeatsFares=? where flightNo=?";
	String SELECT_PASSENGER_LIST="SELECT * FROM BOOKINGINFORMATION WHERE FLIGHTNO=?";
	String SELECT_BOOKING_INFO = "SELECT * FROM BookingInformation where FlightNo=?";
	String UPDATE_ARR_DATE = "UPDATE flightInformation SET ArrivalDate = ? WHERE flightNo = ?";
	String UPDATE_DEPT_DATE = "UPDATE flightInformation SET DepartureDate = ? WHERE flightNo = ?";
    String DELETE_FLIGHT_INFO="DELETE FROM flightinformation where flightNo= ?";
    String INSERT_BOOKING_INFO="INSERT INTO BookingInformation VALUES(?,?,?,?,?,?,?,?,?,?)";
    String BOOKING_INFO_SEQUENCE="SELECT book_id.NEXTVAL FROM DUAL";
    String GET_BOOKED_DETAILS="SELECT custEmail,noOfPassengers,classType,totalFare,seatNumber,creditCardInfo,srcCity,destCity,flightno FROM BookingInformation where bookingId=?";
    String SEARCH_SRC_DES="SELECT FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,fIRSTseats,firstSeatsFare,bussseats,BussSeatsFare FROM FLIGHTINFORMATION WHERE SOURCE LIKE ? AND DESTINATION LIKE ?";
   	String DELETE_BOOKING_ID="DELETE FROM BookingInformation WHERE bookingId=?";
   	String INSERT_AIRPORT="INSERT INTO airport(airportName,abbrevation,location) VALUES (?,?,?)";
   	String INSERT_AIRPORT_LOC="INSERT INTO location(location,state,zipCode) VALUES (?, ?, ?)";
}
