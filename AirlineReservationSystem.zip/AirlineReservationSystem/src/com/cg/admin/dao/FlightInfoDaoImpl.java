package com.cg.admin.dao;


import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;






import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.admin.dto.Airport;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.dto.Location;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.FlightException;
import com.cg.admin.util.DBUtil;




public class FlightInfoDaoImpl implements FlightInfoDao
{
	Logger flightLogger=null;
	Connection conn;
	
	
	
	public FlightInfoDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
    	flightLogger=Logger.getLogger("FlightInfoDaoImpl.class");
	}






	@Override
	public int insertFlightInformation(FlightInformation fi)
			throws AdminException 
	{
		int dataAdded;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.INSERT_FLIGHT_INFORMATION);
			pst.setInt(1,fi.getFlightNo());
			pst.setString(2, fi.getAirline());
			pst.setString(3, fi.getDeptCity());
			pst.setString(4, fi.getArrCity());
			pst.setDate(5, Date.valueOf(fi.getDeptDate()));
			pst.setDate(6, Date.valueOf(fi.getArrDate()));
			pst.setString(7, fi.getDeptTime());
			pst.setString(8, fi.getArrTime());
			pst.setInt(9,fi.getFirstSeats());
			pst.setDouble(10, fi.getFirstSeatsFare());
			pst.setInt(11, fi.getBussSeats());
			pst.setDouble(12, fi.getBussSeatsFare());
			pst.setInt(13, fi.getAvlFirstSeats());
			pst.setInt(14, fi.getAvlBussSeats());
			
			dataAdded=pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"flight Inserted"+ fi );

		}
		catch (Exception e) 
		{
			throw new AdminException("Problem in inserting Flight Details, flight ID " +fi.getFlightNo() +" already exists");
			
		} 
		
		
		
		return dataAdded;
	}

	
	

	

	@Override
	public FlightInformation getFlight(FlightInformation fi)
			throws AdminException 
	{
		
		return null;
	}

	@Override
	public ArrayList<FlightInformation> getFlightList(FlightInformation fi)
			throws AdminException 
	{
		
		return null;
	}






	@Override
	public int updateFlightDeptDate(LocalDate deptDate, int flightNo)
			throws AdminException 
	{
		int dataUpdated2 = 0;
		PreparedStatement pst;
		
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_DEPT_DATE);
			pst.setInt(2, flightNo);
			pst.setDate(1, Date.valueOf(deptDate));
			dataUpdated2=pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ dataUpdated2 );

		
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Updating Flight Date Details");
		}
		return dataUpdated2;
		
	}






	@Override
	public int updateFlightArrDate(LocalDate arrDate, int flightNo)
			throws AdminException {
		int dataUpdated1 = 0;
		PreparedStatement pst;
		
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_ARR_DATE);
			pst.setInt(2, flightNo);
			pst.setDate(1, Date.valueOf(arrDate));
			dataUpdated1=pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ dataUpdated1 );

		} 
		catch (Exception e) 
		{
			
			throw new AdminException("Problem in Updating Flight Date Details"+e.getMessage());
		}
		return dataUpdated1;
		
	}






	@Override
	public int updateFirstFare(double ffare, int flightNo)
			throws AdminException 
	{
		int fareUpdated1 = 0;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_FIRST_FARES);
			pst.setDouble(1, ffare);
			pst.setInt(2, flightNo);
			fareUpdated1 = pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ fareUpdated1 );

		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Updating Flight Fare Details"+e.getMessage());
		}
		return fareUpdated1;
		
	}






	@Override
	public int updateBussFare(double bfare, int flightNo) throws AdminException 
	{
		int fareUpdated2 = 0;
		PreparedStatement pst;
		try 
		{
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.UPDATE_BUSS_FARES);
			pst.setDouble(1, bfare);
			pst.setInt(2, flightNo);
			fareUpdated2 = pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ fareUpdated2 );

		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Updating Flight Date Details"+e.getMessage());
		}
		return fareUpdated2;
	}






	@Override
	public int updateFlightArrTime(String atime, int flightNo)
			throws AdminException 
	{
		 String UPDATE_ARR_TIME="UPDATE flightInformation set arrivalTime=? WHERE flightNo=?";
	        
	        int dataUpdated1=0;
	        try
	        {
	            conn=DBUtil.getCon();
	            PreparedStatement pst= conn.prepareStatement(UPDATE_ARR_TIME);
	            pst.setString(1,atime);
	            pst.setInt(2, flightNo);
	            
	            dataUpdated1 = pst.executeUpdate();
				flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ dataUpdated1 );

	        }
	        
	        catch (Exception e) 
	        {
	            throw new AdminException("Problem in updating Flight Date Details"+e.getMessage());
	            
	        } 
	        
	        return dataUpdated1;
		
	}






	@Override
	public int updateFlightDeptTime(String dtime, int flightNo)
			throws AdminException 
	{
		String UPDATE_DEPT_TIME="UPDATE flightInformation set departureTime=? WHERE flightNo=?";
        int dataUpdated2=0;
        
        try
        {
            conn=DBUtil.getCon();
            PreparedStatement pst= conn.prepareStatement(UPDATE_DEPT_TIME);
            
            pst.setString(1,dtime);
            pst.setInt(2, flightNo);
            
            dataUpdated2 = pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ dataUpdated2 );

        }
        
        catch (Exception e) 
        {
            throw new AdminException("Problem in updating Flight Date Details"+e.getMessage());
            
        } 
        
        return dataUpdated2;
		
	}






	@Override
	public FlightInformation getFlightData(String aCity, LocalDate aDate)
			throws AdminException 
	{
		FlightInformation fi = null;
		try 
		{
			conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.SELECT_FLIGHT_PAR_DAY_PAR_CITY);
			pst.setString(1, aCity);
			pst.setDate(2, Date.valueOf(aDate));
			ResultSet rs = pst.executeQuery();
			if(rs.next())
			{
				fi = new FlightInformation();
				fi.setFlightNo(rs.getInt("FlightNo"));
				fi.setAirline(rs.getString("AirLine"));
				fi.setDeptCity(rs.getString("Source"));
				fi.setArrCity(rs.getString("Destination"));
				fi.setDeptDate(rs.getDate("DepartureDate").toLocalDate());
				fi.setArrDate(rs.getDate("ArrivalDate").toLocalDate());
				fi.setDeptTime(rs.getString("DepartureTime"));
				fi.setArrTime(rs.getString("ArrivalTime"));
				fi.setFirstSeats(rs.getInt("FirstSeats"));
				fi.setFirstSeatsFare(rs.getDouble("FirstSeatsFare"));
				fi.setBussSeats(rs.getInt("BussSeats"));
				fi.setBussSeatsFare(rs.getDouble("BussSeatsFare"));
				fi.setAvlFirstSeats(rs.getInt("FirstSeatsAvail"));
				fi.setAvlBussSeats(rs.getInt("BussSeatsAvail"));
				flightLogger.log(org.apache.log4j.Level.INFO,"Get Flight Info"+ fi );

			}
			else
			{
				throw new AdminException("Flight Details Not Found");
			}
		} 
		catch (Exception e) 
        {
            throw new AdminException("Problem in fetching Flight Details"+e.getMessage());
            
        } 
		return fi;
		
	}






	@Override
	public int updateFlightInformation(String arrCity, int flightNo)
			throws AdminException 
	{
		 int dataUpdated=0;
			try
			{
				conn=DBUtil.getCon(); 
				PreparedStatement pst=conn.prepareStatement(QueryMapper.UPDATE_ARR_CITY);
				 pst.setString(1,arrCity);
				 pst.setInt(2, flightNo);
				  
				 dataUpdated=pst.executeUpdate();
					flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ dataUpdated );

			}
				 catch(Exception e)
					{
				 	
					 throw new AdminException("Problem in Updating Flight Details"+e.getMessage());	
					}
			return dataUpdated;
		
	}






	@Override
	public int updateDeptFlightInfo(String deptCity, int flightNo)
			throws AdminException 
	{
		int dataUpdated=0;
		try
		{
			conn=DBUtil.getCon(); 
			PreparedStatement pst=conn.prepareStatement(QueryMapper.UPDATE_DEPT_CITY);
			 pst.setString(1,deptCity);
			 pst.setInt(2, flightNo);
			  
			 dataUpdated=pst.executeUpdate();
				flightLogger.log(org.apache.log4j.Level.INFO,"Flight Updated"+ dataUpdated );

		}
			 catch(Exception e)
				{
			 	
				 throw new AdminException("Problem in Updating Flight Details"+e.getMessage());	
				}
		return dataUpdated;
		
	}






	@Override
	public int deleteFlightInformation(int flightNo) throws AdminException 
	{
		int dataDeleted=0;
		try
		{
			conn=DBUtil.getCon(); 
			PreparedStatement pst=conn.prepareStatement(QueryMapper.DELETE_FLIGHT_INFO);
			 
			 pst.setInt(1, flightNo);
			  
			 dataDeleted=pst.executeUpdate();
				flightLogger.log(org.apache.log4j.Level.INFO,"Flight Deleted"+ dataDeleted );

		}
			 catch(Exception e)
				{
			 	
				 throw new AdminException("Problem in Deleting Flight Details"+e.getMessage());	
				}
		return dataDeleted;
	}






	@Override
	public void addAirportDetails(Airport a) throws AdminException 
	{
		try 
		{
			Connection conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_AIRPORT);
			pst.setString(1, a.getAirportName());
			pst.setString(2, a.getAbbreviation());
			pst.setString(3, a.getLocationId());
			
			pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Airport Added"+ a );


		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AdminException("Exception from addAirportDetails()",e);
		} 
		
		
		
	}






	@Override
	public void addLocations(Location loc) throws AdminException 
	{
		try
		{
			Connection conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.INSERT_AIRPORT_LOC);
			pst.setString(1, loc.getCity());
			pst.setString(2, loc.getState());
			pst.setString(3, loc.getZipcode());
			
			pst.executeUpdate();
			flightLogger.log(org.apache.log4j.Level.INFO,"Location added"+ loc );


		}
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new AdminException("Exception from addLocationDetails()",e);
		} 
		
	}






	@Override
	public ArrayList<FlightInformation> getEnq(LocalDate depDate)
			throws FlightException 
	{
		Connection con=null;
	    Statement st=null;
	    PreparedStatement pst=null;
	    ResultSet rs=null;
	   
		ArrayList<FlightInformation> Enquiry=new ArrayList<FlightInformation>();
        String selectQry="select flightNo,airline,source,destination,departureTime from FlightInformation where departureDate=?";
        try {
        	
            con=DBUtil.getCon();
            
            pst=con.prepareStatement(selectQry);
            pst.setDate(1,Date.valueOf(depDate));
           
            rs=pst.executeQuery();
            
            while(rs.next())
            {
                 FlightInformation ee = new FlightInformation(rs.getInt(1),
                		rs.getString(2),rs.getString(3),
                		rs.getString(4),rs.getString(5)
                	    );
                 Enquiry.add(ee);
            }
            
        } 
        catch (Exception e) {
        	
            throw new FlightException(e.getMessage());
        }
        finally
        {
            try {
            	
                rs.close();
                pst.close();
                con.close();
            } 
            catch (SQLException e) {
                throw new FlightException(e.getMessage());
            }
        }
        
        return Enquiry;
		
	}






	@Override
	public FlightInformation getFlight(int flightNo, LocalDate depDate)
			throws FlightException 
	{
		Connection con=null;
	    Statement st=null;
	    PreparedStatement pst=null;
	    ResultSet rs=null;
		FlightInformation EnquiryOne=new FlightInformation();
		String selectQry="select flightNo,airline,source,destination,departureDate,departureTime,firstSeats,firstSeatsavail,bussSeats,bussSeatsavail from FlightInformation where flightNo=? and departureDate=?";
		 try {
	        	
	            con=DBUtil.getCon();
	            pst=con.prepareStatement(selectQry);
	            pst.setInt(1,flightNo);
	            pst.setDate(2,Date.valueOf(depDate));
	            rs=pst.executeQuery();
	            while(rs.next())
	            {
	                        EnquiryOne = new FlightInformation(rs.getInt(1),
	                        		rs.getString(2),
	                		rs.getString(3),rs.getString(4),
	                		rs.getDate(5).toLocalDate(),rs.getString(6),
	                		rs.getInt(7),rs.getInt(8),
	                		rs.getInt(9),rs.getInt(10)
	                		);
	              
	            }
		 }
		 catch (Exception e) {
	        	
	            throw new FlightException(e.getMessage());
	        }
	        finally
	        {
	            try {
	            	
	                rs.close();
	                pst.close();
	                con.close();
	            } 
	            catch (SQLException e) {
	                throw new FlightException(e.getMessage());
	            }
	        }
	        
	        return EnquiryOne;
		
	}

}
