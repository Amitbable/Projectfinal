package com.cg.admin.dao;

import java.sql.Statement;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.management.Query;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.admin.dto.BookingInformation;
import com.cg.admin.dto.FlightInformation;
import com.cg.admin.exception.AdminException;
import com.cg.admin.exception.BookingException;
import com.cg.admin.util.DBUtil;

public class BookingInfoDaoImpl implements BookingInfoDao 
{
	Logger bookingLogger=null;
	Connection conn;
	
	

	public BookingInfoDaoImpl() 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
    	bookingLogger=Logger.getLogger("BookingInfoDaoImpl.class");
	}

	@Override
	public int countBookingIds(int fno) throws AdminException 
	{
		int count=0;
		PreparedStatement pst;
		ResultSet rs=null;
		try {
			conn=DBUtil.getCon();
			pst = conn.prepareStatement(QueryMapper.BOOKINGS_FOR_SPECIFIC_FLIGHT);
			pst.setInt(1, fno);
			rs=pst.executeQuery();
			rs.next();
			count=rs.getInt("No_Of_Bookings");
			bookingLogger.log(org.apache.log4j.Level.INFO,"Id counted"+ count );

		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in counting booking id"+e.getMessage());
		} 
		return count;
	}

	@Override
	public List<BookingInformation> getAllBookings(int flightNo)
			throws AdminException 
	{

		List<BookingInformation> bookList=new ArrayList<BookingInformation>();
		try 
		{
			conn=DBUtil.getCon();
			PreparedStatement pst = conn.prepareStatement(QueryMapper.SELECT_BOOKING_INFO);
			pst.setInt(1, flightNo);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				BookingInformation bi=new BookingInformation();
				
				bi.setBookingId(rs.getInt("BookingId"));
				bi.setCustEmail(rs.getString("CustEmail"));
				bi.setNoOfPassengers(rs.getInt("NoOfPassengers"));
				bi.setClassType(rs.getString("ClassType"));
				bi.setTotalFare(rs.getDouble("TotalFare"));
				bi.setSeatNumber(rs.getString("SeatNumber"));
				bi.setCreditCardInfo(rs.getString("creditCardInfo"));
				bi.setSrcCity(rs.getString("SrcCity"));
				bi.setDestCity(rs.getString("DestCity"));
				bi.setFlightNo(rs.getInt("FlightNo"));
				bookList.add(bi);
				bookingLogger.log(org.apache.log4j.Level.INFO,"List Displayed"+ bi );
				
			}
		} 
		catch (Exception e) 
		{
			throw new AdminException("Problem in Fetching Booking list "+e.getMessage());
		}
		
		return bookList;
		
	}

	@Override
	public int addNewBookingInformation(BookingInformation bookInfo)
			throws BookingException 
	{
		int id=0;
		try
		{
			conn=DBUtil.getCon();
			PreparedStatement pst= conn.prepareStatement(QueryMapper.INSERT_BOOKING_INFO);
			id=generateBookingId();
			pst.setInt(1, id);
			pst.setString(2, bookInfo.getCustEmail());
			pst.setInt(3, bookInfo.getNoOfPassengers());
			pst.setString(4, bookInfo.getClassType());
			pst.setDouble(5, bookInfo.getTotalFare());
			pst.setString(6, bookInfo.getSeatNumber());
			pst.setString(7, bookInfo.getCreditCardInfo());
			pst.setString(8, bookInfo.getSrcCity());
			pst.setString(9, bookInfo.getDestCity());
			pst.setInt(10, bookInfo.getFlightNo());
			pst.executeUpdate();
			bookingLogger.log(org.apache.log4j.Level.INFO,"Booking Added"+ bookInfo );
						
			return id;

		}
		catch(SQLException | IOException e)
		{
			throw new BookingException("Problem in inserting booking details of customer");
		}
	}
	
	
	public int generateBookingId() throws BookingException
	{
		int generatedId=0;
		Statement st=null;
		ResultSet rs=null;
		
		try
		{
			conn=DBUtil.getCon();
			st=conn.createStatement();
			rs=st.executeQuery(QueryMapper.SEQUENCE_BOOKING_ID);

			rs.next();
			generatedId=rs.getInt(1);
			bookingLogger.log(org.apache.log4j.Level.INFO,"ID generated"+ generatedId );

		}
		catch(Exception e)
		{
			throw new BookingException(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				st.close();
				conn.close();
			}
			catch(Exception e)
			{
				throw new BookingException(e.getMessage());
			}
		}
		
		return generatedId;
	}

	@Override
	public BookingInformation getBookingInformation(int bookingId)
			throws BookingException
	{
		BookingInformation bookInfo=null;
		ResultSet rs=null;
		try
		{
			Connection conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.GET_BOOKED_DETAILS);
			pst.setInt(1, bookingId);
			rs=pst.executeQuery();
			
			if(rs.next())
			{
				String custEmail=rs.getString(1);
				int noOfPassengers=rs.getInt(2);
				String classType=rs.getString(3);
				Double totalFare=rs.getDouble(4);
				String seatNumber=rs.getString(5);
				String creditCardInfo=rs.getString(6);
				String srcCity=rs.getString(7);
				String destCity=rs.getString(8);
				int flightno = rs.getInt(9);
				bookInfo=new BookingInformation(flightno, bookingId, custEmail, noOfPassengers, classType, totalFare, seatNumber, creditCardInfo, srcCity, destCity);
				bookingLogger.log(org.apache.log4j.Level.INFO,"Booking Info displayed"+ bookInfo );


			}
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			throw new BookingException("Exception from getBookingInformation()",e);
		} finally {
			
			try {
				if(rs!=null)
					rs.close();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}
		return bookInfo;
	}

	@Override
	public boolean deleteBookingInformation(int id) throws BookingException 
	{
		try
		{
			Connection conn=DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.DELETE_BOOKING_ID);
			pst.setInt(1, id);
			int flag=pst.executeUpdate();
			bookingLogger.log(org.apache.log4j.Level.INFO,"Booking deleted"+ flag );

			if(flag==1)
				return true;
			else
				return false;
		}
		catch (SQLException | IOException e) {
			// TODO Auto-generated catch block
			throw new BookingException("Exception from deleteBookingInformation()",e);
		}		
	}

	@Override
	public ArrayList<FlightInformation> searchFlightInformation(String src,
			String destination) throws BookingException {
		FlightInformation obj=null;
		ResultSet rs=null;
		
		ArrayList<FlightInformation> FlightInfoList=new ArrayList<>(); 
		try {
			Connection conn=DBUtil.getCon();
			PreparedStatement pps=conn.prepareStatement(QueryMapper.SEARCH_SRC_DES);
			pps.setString(1, src);
			pps.setString(2, destination);
			rs = pps.executeQuery();
			while(rs.next())
			{
				int FlightNo=rs.getInt(1);
				String AirLine=rs.getString(2);
				String Source=rs.getString(3);
				String Destination=rs.getString(4);
				LocalDate DepartureDate=rs.getDate(5).toLocalDate();
				LocalDate ArrivalDate=rs.getDate(6).toLocalDate();
				String DepartureTime=rs.getString(7);
				String ArrivalTime=rs.getString(8);
				int EconomySeats=rs.getInt(9);
				double EconomySeatsFare=rs.getDouble(10);
				int BusinessSeats=rs.getInt(11);
				double BusinessSeatsFare=rs.getDouble(12);
				
				obj=new FlightInformation(FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,EconomySeats,EconomySeatsFare,BusinessSeats,BusinessSeatsFare);
				FlightInfoList.add(obj);
				bookingLogger.log(org.apache.log4j.Level.INFO,"Search Done"+ FlightInfoList );

		} 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new BookingException("Exception from searchSrcDesBookingInformation()",e);
		} 
		return FlightInfoList;
	}

	@Override
	public FlightInformation getParticularFlight(int fno)
			throws BookingException
	{
		FlightInformation obj=null;
		ResultSet rs=null;
		
		 
		try {
			Connection conn=DBUtil.getCon();
			PreparedStatement pps=conn.prepareStatement(QueryMapper.SELECt_PARTICULAR_FLIGHT);
			pps.setInt(1, fno);
			rs = pps.executeQuery();
			while(rs.next())
			{
				int FlightNo=rs.getInt(1);
				String AirLine=rs.getString(2);
				String Source=rs.getString(3);
				String Destination=rs.getString(4);
				LocalDate DepartureDate=rs.getDate(5).toLocalDate();
				LocalDate ArrivalDate=rs.getDate(6).toLocalDate();
				String DepartureTime=rs.getString(7);
				String ArrivalTime=rs.getString(8);
				int EconomySeats=rs.getInt(9);
				double EconomySeatsFare=rs.getDouble(10);
				int BusinessSeats=rs.getInt(11);
				double BusinessSeatsFare=rs.getDouble(12);
				int availecoseats=rs.getInt(13);
				int availbussseats=rs.getInt(14);
				obj=new FlightInformation(FlightNo,AirLine,Source,Destination,DepartureDate,ArrivalDate,DepartureTime,ArrivalTime,EconomySeats,EconomySeatsFare,BusinessSeats,BusinessSeatsFare,availecoseats,availbussseats);
				bookingLogger.log(org.apache.log4j.Level.INFO,"Info displayed of Particluar flight"+ obj );

		} 
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw new BookingException("Exception from searchSrcDesBookingInformation()",e);
		} 
		return obj;
	}

	@Override
	public boolean updateFlightSeatsCNF(FlightInformation f)
			throws BookingException
	{
		Connection conn;
		try 
		{
			conn = DBUtil.getCon();
			PreparedStatement pst=conn.prepareStatement(QueryMapper.Update_SUCCESS_SEATS);
			pst.setInt(1, f.getAvlFirstSeats());
			pst.setInt(2, f.getAvlBussSeats());
			pst.setInt(3, f.getFlightNo());
			int count = pst.executeUpdate(); // returns the no. of records affected.
			 if(count>0)
			 {
				 return true;
			 }
			 else return false;
		

		} 
		catch (Exception e) 
		{
			e.printStackTrace();
			throw new BookingException("Exception from searchSrcDesBookingInformation()",e);
		} 
		
		
	}
	
	
}


